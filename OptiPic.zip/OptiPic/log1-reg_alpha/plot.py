
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import gridspec
#fig, ax = plt.subplots(1, 2, figsize=(14, 5))
#gs = gridspec.GridSpec(1, 2, wspace=0.2, hspace=0.3, width_ratios=[1, 1])

path1 = 'vae_halfcheetah-medium-expert-v2.txt'
#path2 = '/mnt/c/Users/liuya/Downloads/optdice_halfcheetah-medium-expert-v2-bc.txt'

scores = []
for line in open(path1):
    if 'eval ' in line:
        score = float(line.split()[1])
        scores.append(score)
#plt.subplot(gs[0, 0])
#scores = pd.DataFrame(scores)
#scores = scores.rolling(window=2, min_periods=1, center=True).mean() 
plt.plot(range(len(scores)), scores, color='g')
plt.title('vae', fontsize=30, fontname='cmb10')
plt.savefig('vae.png')
